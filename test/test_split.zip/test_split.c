#include <stdio.h>
#include <stdlib.h>
#include <string.h>

// Function prototypes
int is_sep(char *charset, char c);
int count(char *str, char *charset);
char *skip(char *str, char *charset, int *len);
char *ft_strncpy(char *dest, char *src, int n);
char **ft_split(char *str, char *charset);

// Test function
void test_ft_split(char *str, char *charset) {
    printf("Input string: \"%s\"\n", str);
    printf("Charset: \"%s\"\n", charset);

    // Test ft_split function
    char **result = ft_split(str, charset);

    if (result == NULL) {
        printf("ft_split returned NULL.\n");
        return;
    }

    // Display the result
    printf("Resulting words:\n");
    for (int i = 0; result[i] != NULL; i++) {
        printf("%s\n", result[i]);
        free(result[i]);
    }

    // Free the allocated memory
    free(result);

    printf("\n");
}

int main() {
    // Test cases
    char *str1 = "Hello, world!";
    char *charset1 = " ,!";
    test_ft_split(str1, charset1);

    char *str2 = "apple,orange,grape";
    char *charset2 = ",";
    test_ft_split(str2, charset2);

    char *str3 = "Split by any character";
    char *charset3 = " ";
    test_ft_split(str3, charset3);

    char *str4 = "1234567890";
    char *charset4 = "1234567890";
    test_ft_split(str4, charset4);

    char *str5 = "No splitting";
    char *charset5 = "";
    test_ft_split(str5, charset5);

    char *str6 = NULL;
    char *charset6 = ", ";
    test_ft_split(str6, charset6);

    char *str7 = "";
    char *charset7 = " ,";
    test_ft_split(str7, charset7);

    char *str8 = "Hello, world!";
    char charset8[] = { ' ', ',', '\0' };
    test_ft_split(str8, charset8);

    char *str9 = "apple,,orange";
    char *charset9 = ",";
    test_ft_split(str9, charset9);

    char *str10 = ",,,";
    char *charset10 = ",";
    test_ft_split(str10, charset10);

    char *str11 = "The|quick|brown|fox";
    char *charset11 = "|pqu";
    test_ft_split(str11, charset11);

    return 0;
}
